import React from 'react';
import { useAppStore } from './store/appStore';
import { TopNav } from './components/TopNav';
import { Viewer3DTab } from './components/Viewer3DTab';
import { DataTableTab } from './components/DataTableTab';
import { TransformTab } from './components/TransformTab';
import { SimpAnalysisTab } from './components/SimpAnalysisTab';
import { Spl2BundleTab } from './spl2-bundle';
import { ConfigTab } from './config/ConfigTab';
import SketcherTab from './sketcher/SketcherTab';
import { GC3DTab } from './gc3d';
import './App.css';

function App() {
  const activeTab = useAppStore(state => state.activeTab);

  // Expose store for e2e testing
  if (typeof window !== 'undefined') {
    window.useAppStore = useAppStore;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', fontFamily: 'sans-serif', background: '#0f172a', position: 'relative' }}>
      <TopNav />
      {activeTab === 'viewer' && <Viewer3DTab />}
      {activeTab === 'datatable' && <DataTableTab />}
      {activeTab === 'transform' && <TransformTab />}
      {activeTab === 'sketcher' && <SketcherTab />}
      {activeTab === 'simpAnalysis' && <SimpAnalysisTab />}
      {activeTab === 'spl2bundle' && <Spl2BundleTab />}
      {activeTab === 'config' && <ConfigTab />}
      {activeTab === 'gc3d' && <GC3DTab />}
      
      {/* Versioning Status */}
      <div style={{ position: 'absolute', bottom: '4px', right: '8px', fontSize: '10px', color: '#64748b', zIndex: 1000, pointerEvents: 'none' }}>
        ver.28-02-25 time 12.00
      </div>
    </div>
  );
}

export default App;
