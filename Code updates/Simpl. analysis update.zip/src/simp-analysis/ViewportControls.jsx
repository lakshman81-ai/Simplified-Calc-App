import React, { useRef, useState } from 'react';
import { OrthographicCamera, Grid } from '@react-three/drei';
import { useThree, useFrame } from '@react-three/fiber';
import { useSimpStore } from './store';

export const ViewportControls = () => {
  const plane = useSimpStore(state => state.plane);
  const cameraRef = useRef();

  // Set camera based on plane
  let camPos = [3000, 2000, 20000];
  let up = [0, 1, 0];
  if (plane === 'XZ') {
    camPos = [3000, 20000, 0];
    up = [0, 0, -1];
  } else if (plane === 'YZ') {
    camPos = [20000, 2000, 0];
    up = [0, 1, 0];
  }

  const gridRef = useRef();

  // Dynamically scale grid based on zoom without causing re-renders
  useFrame(({ camera }) => {
    if (camera.type === 'OrthographicCamera' && gridRef.current) {
      const zoom = camera.zoom;
      let sectionSize = 1000;
      let cellSize = 100;
      let fadeDistance = 50000;

      if (zoom < 0.05) {
        sectionSize = 10000;
        cellSize = 1000;
        fadeDistance = 200000;
      } else if (zoom > 0.5) {
        sectionSize = 100;
        cellSize = 10;
        fadeDistance = 10000;
      } else if (zoom > 2) {
        sectionSize = 10;
        cellSize = 1;
        fadeDistance = 1000;
      }

      // Mutate grid material uniforms directly to avoid component re-renders
      if (gridRef.current.material) {
        gridRef.current.material.sectionSize = sectionSize;
        gridRef.current.material.cellSize = cellSize;
        gridRef.current.material.fadeDistance = fadeDistance;
      }
    }
  });

  return (
    <>
      <OrthographicCamera 
        ref={cameraRef}
        makeDefault 
        position={camPos} 
        zoom={0.1} 
        near={-100000} 
        far={100000} 
        up={up} 
      />
      <Grid 
        ref={gridRef}
        infiniteGrid 
        fadeDistance={50000} 
        sectionSize={1000} 
        cellSize={100}
        cellColor="#444444" 
        sectionColor="#666666" 
        position={[0,0,0]}
        rotation={plane === 'XZ' ? [0, 0, 0] : plane === 'YZ' ? [0, 0, Math.PI/2] : [Math.PI/2, 0, 0]}
      />
    </>
  );
};
