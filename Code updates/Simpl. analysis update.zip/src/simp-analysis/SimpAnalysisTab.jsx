import React, { useEffect } from 'react';
import { SimpAnalysisCanvas } from './SimpAnalysisCanvas';
import { CalculationsPanel } from './CalculationsPanel';
import { useSimpStore } from './store';
import { mockData } from './mock-data';

export const SimpAnalysisTab = () => {
  const importFromViewer3D = useSimpStore(state => state.importFromViewer3D);
  const setNodes = useSimpStore(state => state.setNodes);
  const setSegments = useSimpStore(state => state.setSegments);
  const setPlane = useSimpStore(state => state.setPlane);
  const plane = useSimpStore(state => state.plane);

  // Load geometry data
  useEffect(() => {
    // Call importFromViewer3D with empty array as a fallback
    // extractSubGraph handles empty arrays by loading default mock structural nodes.
    // However, if we have explicit mock data we should use setNodes/setSegments directly to initialize
    // since importFromViewer3D expects raw component data, not already-extracted nodes.
    const tryExtract = () => {
      if (window._state && window._state.viewer3dComponents && window._state.viewer3dComponents.length > 0) {
        importFromViewer3D(window._state.viewer3dComponents);
      } else {
        setNodes(mockData.nodes);
        setSegments(mockData.segments);
      }
    };
    tryExtract();
    
    const interval = setInterval(() => {
        if (window._state && window._state.viewer3dComponents && window._state.viewer3dComponents.length > 0) {
            importFromViewer3D(window._state.viewer3dComponents);
            clearInterval(interval);
        }
    }, 1000);
    return () => clearInterval(interval);
    
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', fontFamily: 'sans-serif' }}>
      
      {/* Top Bar */}
      <div style={{ height: '50px', background: '#1e1e1e', color: 'white', display: 'flex', alignItems: 'center', padding: '0 20px', borderBottom: '1px solid #333' }}>
        <h2 style={{ margin: 0, fontSize: '18px', marginRight: '20px' }}>Smart 2D Analyzer (GCM)</h2>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <label style={{ fontSize: '12px', color: '#aaa' }}>Analysis Plane:</label>
          <select 
            value={plane} 
            onChange={(e) => setPlane(e.target.value)}
            style={{ padding: '5px', background: '#2c2c2c', color: 'white', border: '1px solid #555' }}
          >
            <option value="XY">XY Plane (Plan)</option>
            <option value="XZ">XZ Plane (Elevation)</option>
            <option value="YZ">YZ Plane (Elevation)</option>
          </select>
        </div>
      </div>

      {/* Main Content */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <div style={{ flex: 1, position: 'relative' }}>
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}><SimpAnalysisCanvas /></div>
        </div>
        <CalculationsPanel />
      </div>

    </div>
  );
};

export default SimpAnalysisTab;
