import React, { useRef, useState } from 'react';
import { useSimpStore } from './store';
import { Html, TransformControls } from '@react-three/drei';

const PipingNode = ({ id, node, plane }) => {
  const meshRef = useRef();
  const moveNode = useSimpStore(state => state.moveNode);
  const setOrbitEnabled = useSimpStore(state => state.setOrbitEnabled);
  const [active, setActive] = useState(false); // Active state to track dragging

  // Logic to strictly lock the axis not in the active plane
  const showX = plane !== 'YZ';
  const showY = plane !== 'XZ';
  const showZ = plane !== 'XY';

  const onDragStart = (e) => {
    // TransformControls fires dragging-changed event
    if (e.value) {
      setActive(true);
      setOrbitEnabled(false); // Disable map panning when dragging
    } else {
      setActive(false);
      setOrbitEnabled(true); // Re-enable map panning
    }
  };

  const onChange = (e) => {
    if (!e || !e.target || !e.target.object || !active) return;
    
    let { x, y, z } = e.target.object.position;
    
    // Mathematically lock the translation depending on the plane
    if (plane === 'XY') z = node.pos[2];
    if (plane === 'XZ') y = node.pos[1];
    if (plane === 'YZ') x = node.pos[0];

    // Grid snap to 100mm
    x = Math.round(x / 100) * 100;
    y = Math.round(y / 100) * 100;
    z = Math.round(z / 100) * 100;

    // Only update if position actually changed to avoid infinite loop
    if (node.pos[0] !== x || node.pos[1] !== y || node.pos[2] !== z) {
      e.target.object.position.set(x, y, z);
      moveNode(id, [x, y, z]);
    }
  };

  return (
    <>
      <TransformControls
        object={meshRef}
        mode="translate"
        showX={showX}
        showY={showY}
        showZ={showZ}
        onDraggingChanged={onDragStart}
        onChange={onChange}
        size={2}
      />
      <mesh ref={meshRef} position={node.pos}>
        <sphereGeometry args={[200, 32, 32]} />
        <meshStandardMaterial color={node.type === 'anchor' ? 'blue' : 'orange'} />
        <Html position={[0, 300, 0]} center zIndexRange={[100, 0]}>
          <div style={{color: 'white', background: 'black', padding: '2px 5px', fontSize: '10px'}}>{id}</div>
        </Html>
      </mesh>
    </>
  );
};

export const PipingNodes = () => {
  const nodes = useSimpStore(state => state.nodes);
  const plane = useSimpStore(state => state.plane);

  return (
    <group>
      {Object.entries(nodes).map(([id, node]) => (
        <PipingNode key={id} id={id} node={node} plane={plane} />
      ))}
    </group>
  );
};
