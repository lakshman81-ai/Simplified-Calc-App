import React, { useMemo } from 'react';
import { useSimpStore } from './store';
import { Vector3, Quaternion } from 'three';
import { Html } from '@react-three/drei';

export const PipingSegments = () => {
  const nodes = useSimpStore(state => state.nodes);
  const segments = useSimpStore(state => state.segments);
  const stats = useSimpStore(state => state.stats);
  const params = useSimpStore(state => state.params);

  const segmentsData = useMemo(() => {
    return segments.map((seg, i) => {
      const p1 = new Vector3(...nodes[seg.start].pos);
      const p2 = new Vector3(...nodes[seg.end].pos);
      const vec = p2.clone().sub(p1);
      const dist = vec.length();
      const pos = p1.clone().add(p2).divideScalar(2);
      
      // Calculate rotation. Cylinder naturally goes along Y axis.
      // We want it to point along 'vec'.
      const quaternion = new Quaternion().setFromUnitVectors(new Vector3(0, 1, 0), vec.clone().normalize());
      
      const isGenerator = i === 0;
      const isAbsorber = i === 1;
      let color = 'gray';
      
      if (stats.ratio > 0) {
        if (isAbsorber) color = stats.ratio <= 1.0 ? 'green' : 'red';
        else if (isGenerator) color = '#aaffaa'; // Light green for generator leg
      }

      return { key: `seg-${i}`, dist, pos, quaternion, color, isAbsorber, isGenerator };
    });
  }, [nodes, segments, stats.ratio, stats.Lreq, params.od]);

  return (
    <group>
      {segmentsData.map(({ key, dist, pos, quaternion, color, isAbsorber, isGenerator }) => (
        <mesh key={key} position={pos} quaternion={quaternion}>
          <cylinderGeometry args={[params.od/2, params.od/2, dist, 16]} />
          <meshStandardMaterial color={color} />
          <Html position={[0, params.od + 50, 0]} center zIndexRange={[100, 0]}>
            <div style={{color: 'white', background: 'rgba(0,0,0,0.8)', padding: '4px 8px', borderRadius: '4px', fontSize: '11px', whiteSpace: 'nowrap', textAlign: 'center'}}>
              <strong style={{color: isGenerator ? '#aaffaa' : isAbsorber ? (stats.ratio <= 1.0 ? '#aaffaa' : '#ffaaaa') : 'white'}}>
                {isGenerator ? 'Generator Leg' : isAbsorber ? 'Absorber Leg' : `Segment`}
              </strong>
              <div style={{marginTop: '2px'}}>Length: {dist.toFixed(1)} mm</div>
              <div style={{marginTop: '2px', color: '#aaaaaa'}}>Bore OD: {params.od} mm</div>
              {isAbsorber && stats.ratio > 0 && (
                <div style={{marginTop: '4px', borderTop: '1px solid #555', paddingTop: '4px', color: stats.ratio <= 1.0 ? '#aaffaa' : '#ffaaaa'}}>
                  Req L: {stats.Lreq.toFixed(1)} mm
                </div>
              )}
            </div>
          </Html>
        </mesh>
      ))}
    </group>
  );
};
